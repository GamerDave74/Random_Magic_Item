import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import csv
import random
import os

class MagicItemGenerator:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Arcane Treasury Generator")
        self.root.geometry("1000x800")
        self.root.configure(bg='#1a0f0a')
        
        # Data storage
        self.item_tables = {}
        self.all_items = []
        self.total_items = 0
        
        # Store last generation info for reroll functionality
        self.last_generation = {
            'category': None,
            'table_id': None,
            'items': [],
            'available': False
        }
        
        # Store current item for enhancement
        self.current_item = {
            'name': None,
            'original_name': None,
            'category': None,
            'table': None,
            'available': False,
            'ee_count': 0,      # Track EE enhancements applied
            'quirks_count': 0   # Track Quirks enhancements applied
        }
        
        # Load CSV data
        self.load_csv_data()
        
        # Create GUI
        self.create_gui()
        
    def load_csv_data(self):
        """Load all CSV files with exact matching names"""
        table_files = [
            ('A', 'Table_A.csv', 'Magical Liquids'),
            ('B', 'Table_B.csv', 'Scrolls'), 
            ('C', 'Table_C.csv', 'Rings'),
            ('D', 'Table_D.csv', 'Rods'),
            ('E', 'Table_E.csv', 'Staves'),
            ('F', 'Table_F.csv', 'Wands'),
            ('G', 'Table_G.csv', 'Books'),
            ('H', 'Table_H.csv', 'Gems & Jewelry'),
            ('I', 'Table_I.csv', 'Clothing'),
            ('J', 'Table_J.csv', 'Boots & Gloves'),
            ('K', 'Table_K.csv', 'Girdles & Helmets'),
            ('L', 'Table_L.csv', 'Bags & Bottles'),
            ('M', 'Table_M.csv', 'Dust & Stones'),
            ('N', 'Table_N.csv', 'Household Items'),
            ('O', 'Table_O.csv', 'Musical Instruments'),
            ('P', 'Table_P.csv', 'Weird Stuff'),
            ('Q', 'Table_Q.csv', 'Humorous Items'),
            ('R1', 'Table_R1.csv', 'Armor and Shields'),
            ('R2', 'Table_R2.csv', 'Armor and Shields'),
            ('R3', 'Table_R3.csv', 'Armor and Shields'),
            ('S1', 'Table_S1.csv', 'Weapons'),
            ('S2', 'Table_S2.csv', 'Weapons'),
            ('S3', 'Table_S3.csv', 'Weapons'),
            ('T', 'Table_T.csv', 'Final Items'),
            ('1', 'Table_1.csv', 'Main Category Table'),
            # Enhancement tables
            ('EE', 'EE_Table.csv', 'Enchanted Enhancements'),
            ('QE', 'QE_Table.csv', 'Quirk Effects'),
            ('QP', 'QP_Table.csv', 'Quirks Present'),
            ('AE', 'AE_Table.csv', 'Aquatic Enhancements'),
            ('RE', 'RE_Table.csv', 'Racial Enhancements'),
        ]
        
        print("Loading CSV files...")
        
        for table_id, filename, category in table_files:
            file_path = os.path.join('data', 'tables', filename)
            if os.path.exists(file_path):
                print(f"✓ Found: {filename}")
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        reader = csv.DictReader(f)
                        items = []
                        
                        for row in reader:
                            item_name = None
                            roll_from = None
                            roll_to = None
                            
                            # Find item name - expanded column search for enhancement tables
                            for col in ['Item Discovered', 'Generic Magic Weapon', 'Item', 'Magical Item Category', 'd100 Roll', 'Type', 'Effect', 'Quirks Present', 'Variant', 'Race']:
                                if col in row and row[col] and row[col].strip():
                                    item_name = str(row[col]).strip()
                                    break
                            
                            # Special handling for Table_S2
                            if table_id == 'S2':
                                for col in ['Roll From', 'Roll (Low)', 'Roll Low']:
                                    if col in row and row[col] is not None and str(row[col]).strip():
                                        try:
                                            roll_from = int(row[col])
                                            break
                                        except ValueError:
                                            pass
                                
                                for col in ['Roll to', 'Roll To', 'Roll (High)', 'Roll High']:
                                    if col in row and row[col] is not None and str(row[col]).strip():
                                        try:
                                            roll_to = int(row[col])
                                            break
                                        except ValueError:
                                            pass
                                
                                if not item_name and roll_from is not None:
                                    wpn_adj = row.get('Wpn Adj', '')
                                    wpn_xp = row.get('Wpn XP Val', '')
                                    gp_val = row.get('GP Value', '')
                                    
                                    if wpn_adj is not None and str(wpn_adj).strip() != '':
                                        wpn_adj_val = int(wpn_adj)
                                        if wpn_adj_val > 0:
                                            item_name = f"+{wpn_adj_val} enhancement, {wpn_xp} XP, {gp_val} GP"
                                        elif wpn_adj_val < 0:
                                            item_name = f"{wpn_adj_val} cursed, {wpn_xp} XP, {gp_val} GP"
                                        else:
                                            item_name = f"normal weapon, {wpn_xp} XP, {gp_val} GP"
                            
                            # Special handling for R2
                            elif table_id == 'R2' and not item_name:
                                ac_adj = row.get('AC Adj', '')
                                xp_val = row.get('XP Value', '')
                                gp_val = row.get('GP Value', '')
                                if ac_adj and str(ac_adj).strip():
                                    if float(ac_adj) > 0:
                                        item_name = f"+{ac_adj} AC bonus, {xp_val} XP, {gp_val} GP"
                                    elif float(ac_adj) < 0:
                                        item_name = f"{ac_adj} AC penalty, {xp_val} XP, {gp_val} GP"
                                    else:
                                        item_name = f"normal armor, {xp_val} XP, {gp_val} GP"
                            
                            # Standard roll range parsing
                            if table_id != 'S2' and roll_from is None:
                                for col in ['Roll From', 'Roll (Low)', 'Roll Low', 'Roll low', 'Low Roll', 'd100 Roll']:
                                    if col in row and row[col] and str(row[col]).strip():
                                        try:
                                            roll_from = int(row[col])
                                            break
                                        except ValueError:
                                            if '-' in str(row[col]):
                                                parts = str(row[col]).split('-')
                                                if len(parts) == 2:
                                                    try:
                                                        roll_from = int(parts[0])
                                                        break
                                                    except ValueError:
                                                        pass
                                
                                for col in ['Roll To', 'Roll (High)', 'Roll High', 'Roll high', 'High Roll', 'Roll to']:
                                    if col in row and row[col] and str(row[col]).strip():
                                        try:
                                            roll_to = int(row[col])
                                            break
                                        except ValueError:
                                            pass
                                
                                if roll_from is not None and roll_to is None:
                                    for col in ['d100 Roll']:
                                        if col in row and row[col] and '-' in str(row[col]):
                                            parts = str(row[col]).split('-')
                                            if len(parts) == 2:
                                                try:
                                                    roll_to = int(parts[1])
                                                    break
                                                except ValueError:
                                                    pass
                            
                            if item_name and item_name != '' and roll_from is not None:
                                item = {
                                    'name': item_name,
                                    'roll_from': roll_from,
                                    'roll_to': roll_to if roll_to is not None else roll_from,
                                    'category': category,
                                    'table': table_id
                                }
                                
                                if table_id == '1':
                                    item['Magical Item Category'] = row.get('Magical Item Category', '')
                                    item['Tables'] = row.get('Tables', '')
                                
                                items.append(item)
                                self.all_items.append(item)
                        
                        self.item_tables[table_id] = {
                            'category': category,
                            'items': items,
                            'filename': filename
                        }
                        
                        self.total_items += len(items)
                        print(f"   Loaded {len(items)} items from {category}")
                        
                except Exception as e:
                    print(f"   Error reading {filename}: {e}")
                    
            else:
                print(f"✗ Missing: {filename}")
        
        print(f"\nTotal items loaded: {self.total_items}")
        print(f"Tables loaded: {len(self.item_tables)}")
    
    def has_enhancement_symbols(self, item_name):
        """Check if item has enhancement symbols"""
        name = item_name.strip()
        if name.startswith('**') and name.endswith('**'):
            return False
        symbols = '*#%@&^$'
        return any(s in name for s in symbols)
    
    def is_reroll_item(self, item_name):
        """Check if item has enhancement symbols"""
        return self.has_enhancement_symbols(item_name)
    
    def is_unique_artifact(self, item_name):
        """Check if item is **unique** artifact"""
        name = item_name.strip()
        return name.startswith('**') and name.endswith('**')
    
    def clean_unique_name(self, item_name):
        """Remove ** markers from unique artifacts"""
        if self.is_unique_artifact(item_name):
            return item_name.strip('*')
        return item_name
    
    def parse_enhancement_symbols(self, item_name):
        """Parse all enhancement symbols from item name"""
        symbols = {
            'reroll': '*' in item_name,
            'enchanted': '#' in item_name, 
            'aquatic': '%' in item_name,
            'quirks': '@' in item_name,
            'racial': '&' in item_name,
            'no_duplicate': '^' in item_name,
            'weapon_enhancement': '$' in item_name
        }
        
        # Get base name without symbols
        base_name = item_name
        for symbol in '*#%@&^$':
            base_name = base_name.replace(symbol, '')
        symbols['base_name'] = base_name.strip()
        
        return symbols
    
    def process_enhanced_item(self, item_name, source_table, applied_enhancements=None, max_enhancements=3):
        """Process item with enhancement symbols"""
        if applied_enhancements is None:
            applied_enhancements = []
        
        processing_log = []
        
        # Check for unique artifacts first
        if self.is_unique_artifact(item_name):
            clean_name = self.clean_unique_name(item_name)
            processing_log.append(f"✨ Unique artifact: {item_name} → {clean_name}")
            return clean_name, processing_log, applied_enhancements
        
        # Parse enhancement symbols
        symbols = self.parse_enhancement_symbols(item_name)
        base_name = symbols['base_name']
        
        # SPECIAL CASE: If this is "Racial Enhancements" and RE table is empty, skip entirely
        if base_name == "Racial Enhancements" and ('RE' not in self.item_tables or not self.item_tables['RE']['items']):
            processing_log.append(f"👥 Racial Enhancement for: {base_name}")
            processing_log.append(f"⚠️ RE table is empty - skipping racial enhancement completely")
            # Return just the base item without the racial enhancement
            return "", processing_log, applied_enhancements
        
        # Track current item for building final name
        current_item = base_name
        
        # Handle reroll for base item - BUILD THE CHAIN WITH LIMIT
        if symbols['reroll']:
            reroll_result, base_log = self.roll_for_base_item_chain(source_table, applied_enhancements)
            processing_log.extend(base_log)
            
            # Combine base name with reroll chain
            if reroll_result != base_name and reroll_result:
                current_item = f"{base_name} + {reroll_result}"
            else:
                current_item = base_name
        
        # Handle weapon enhancement first ($ symbol)
        if symbols['weapon_enhancement']:
            enhanced_item, weapon_log = self.process_weapon_enhancement(current_item, applied_enhancements)
            processing_log.extend(weapon_log)
            return enhanced_item, processing_log, applied_enhancements
        
        # Handle other enhancements (max 3 total)
        if len(applied_enhancements) < max_enhancements:
            # Enchanted Enhancements (#)
            if symbols['enchanted']:
                enhanced_item, ee_log, applied_enhancements = self.process_enchanted_enhancement(current_item, applied_enhancements, max_enhancements)
                processing_log.extend(ee_log)
                current_item = enhanced_item
            
            # Aquatic (%)
            if symbols['aquatic']:
                enhancement_name = "Aquatic"
                if symbols['no_duplicate'] and enhancement_name in applied_enhancements:
                    processing_log.append(f"🚫 {enhancement_name} already applied, skipping")
                else:
                    enhanced_item, aquatic_log = self.process_aquatic_enhancement(current_item)
                    processing_log.extend(aquatic_log)
                    current_item = enhanced_item
                    if symbols['no_duplicate']:
                        applied_enhancements.append(enhancement_name)
            
            # Quirks (@)
            if symbols['quirks']:
                enhanced_item, quirk_log = self.process_quirks_enhancement(current_item)
                processing_log.extend(quirk_log)
                current_item = enhanced_item
            
            # Racial (&)
            if symbols['racial']:
                # Check if RE table is available
                if 'RE' not in self.item_tables or not self.item_tables['RE']['items']:
                    processing_log.append(f"👥 Racial Enhancement for: {current_item}")
                    processing_log.append(f"⚠️ RE table is empty - skipping racial enhancement")
                    # Don't modify current_item, just skip the enhancement
                else:
                    enhanced_item, racial_log = self.process_racial_enhancement(current_item)
                    processing_log.extend(racial_log)
                    current_item = enhanced_item
        else:
            processing_log.append(f"🚫 Max enhancements ({max_enhancements}) reached")
        
        return current_item, processing_log, applied_enhancements
    
    def apply_manual_ee_enhancement(self, base_item_name, applied_enhancements=None, max_enhancements=3):
        """Manually apply EE enhancement to any item - allow up to 3 EE enhancements total"""
        if applied_enhancements is None:
            applied_enhancements = []
        
        processing_log = []
        
        # Apply EE enhancement
        enhanced_item, ee_log, updated_enhancements = self.process_enchanted_enhancement(
            base_item_name, [], max_enhancements  # Start fresh for each manual application
        )
        processing_log.extend(ee_log)
        
        return enhanced_item, processing_log, updated_enhancements

    def apply_manual_quirks_enhancement(self, base_item_name):
        """Manually apply Quirks enhancement to any item"""
        processing_log = []
        
        # Apply Quirks enhancement
        enhanced_item, quirks_log = self.process_quirks_enhancement(base_item_name)
        processing_log.extend(quirks_log)
        
        return enhanced_item, processing_log
    
    def roll_for_base_item_chain(self, source_table, applied_enhancements):
        """Roll same table for base item and build enhancement chain"""
        log = []
        enhancement_chain = []
        seen_enhancements = set()  # Track duplicate enhancements for ^ symbol
        
        if source_table not in self.item_tables:
            log.append(f"⚠️ Source table {source_table} not available")
            return "Unknown Item", log
        
        table_items = self.item_tables[source_table]['items']
        if not table_items:
            log.append(f"⚠️ Source table {source_table} is empty")
            return "Unknown Item", log
        
        attempts = 0
        max_attempts = 15  # Increased to handle ^ symbol rerolls
        
        while attempts < max_attempts:
            base_item_data = random.choice(table_items)
            base_roll = random.randint(base_item_data['roll_from'], base_item_data['roll_to'])
            base_name = base_item_data['name']
            
            log.append(f"   → Base item roll: {base_roll} → {base_name}")
            
            # Parse the enhancement symbols
            if self.has_enhancement_symbols(base_name):
                symbols = self.parse_enhancement_symbols(base_name)
                clean_name = symbols['base_name']
                
                # Check for no_duplicate (^) symbol
                if symbols['no_duplicate']:
                    # Check if we've already seen this enhancement type (case-insensitive)
                    enhancement_type = clean_name.lower().strip()
                    if enhancement_type in seen_enhancements:
                        log.append(f"   🚫 Duplicate enhancement '{clean_name}' blocked by ^ symbol, rerolling...")
                        attempts += 1
                        continue  # Reroll to get a different enhancement
                    else:
                        seen_enhancements.add(enhancement_type)
                        log.append(f"   ✅ New enhancement '{clean_name}' allowed by ^ symbol")
                
                # Process the enhancement symbols first, then add to chain
                processed_enhancement = clean_name
                
                # Handle specific enhancement symbols
                if symbols['quirks']:
                    processed_enhancement, quirk_log = self.process_quirks_enhancement(clean_name)
                    log.extend([f"      {line}" for line in quirk_log])
                elif symbols['aquatic']:
                    processed_enhancement, aquatic_log = self.process_aquatic_enhancement(clean_name)
                    log.extend([f"      {line}" for line in aquatic_log])
                elif symbols['racial']:
                    # Check if RE table is available before processing
                    if 'RE' not in self.item_tables or not self.item_tables['RE']['items']:
                        log.append(f"      👥 Racial Enhancement for: {clean_name}")
                        log.append(f"      ⚠️ RE table is empty - skipping racial enhancement")
                        log.append(f"   → Racial enhancement failed, skipping from chain")
                        attempts += 1
                        continue  # Skip this enhancement and try again
                    else:
                        processed_enhancement, racial_log = self.process_racial_enhancement(clean_name)
                        log.extend([f"      {line}" for line in racial_log])
                else:
                    # For other symbols like ^ (no duplicate), just use clean name
                    processed_enhancement = clean_name
                
                enhancement_chain.append(processed_enhancement)
                
                # If it has reroll symbol, continue the chain
                if symbols['reroll']:
                    log.append(f"   → Base item has enhancements, continuing chain...")
                    attempts += 1
                    continue  # Keep rolling to build the chain
                else:
                    # No reroll symbol, end the chain
                    break
            else:
                # Regular item, end the chain
                enhancement_chain.append(base_name)
                break
            
            attempts += 1
        
        # Check if we hit max attempts due to ^ symbol conflicts
        if attempts >= max_attempts:
            log.append(f"⚠️ Max attempts reached due to ^ symbol duplicate prevention")
        
        # Build final result from chain
        if enhancement_chain:
            final_result = " + ".join(enhancement_chain)
            return final_result, log
        else:
            # Fallback
            log.append(f"⚠️ Chain building failed, using simple item")
            simple_items = [item for item in table_items if not self.has_enhancement_symbols(item['name'])]
            if simple_items:
                fallback = random.choice(simple_items)
                return fallback['name'], log
            else:
                return table_items[0]['name'], log
    
    def apply_manual_quirks_enhancement(self, base_item_name):
        """Manually apply Quirks enhancement to any item"""
        processing_log = []
        
        # Apply Quirks enhancement
        enhanced_item, quirks_log = self.process_quirks_enhancement(base_item_name)
        processing_log.extend(quirks_log)
        
        return enhanced_item, processing_log
    
    def manual_quirks_enhancement(self):
        """Manually apply Quirks enhancement to the current item"""        
        if not self.current_item['available']:
            messagebox.showwarning("No Item Available", 
                                 "Please generate an item first before applying Quirks enhancement!")
            return
        
        # Check if max Quirks enhancements reached (3 max)
        if self.current_item['quirks_count'] >= 3:
            messagebox.showwarning("Max Quirks Enhancements Reached", 
                                 "This item already has 3 quirks enhancements (maximum allowed)!")
            return
        
        if 'QP' not in self.item_tables or 'QE' not in self.item_tables:
            missing_tables = []
            if 'QP' not in self.item_tables:
                missing_tables.append('QP_Table.csv')
            if 'QE' not in self.item_tables:
                missing_tables.append('QE_Table.csv')
            messagebox.showerror("Quirks Tables Missing", 
                               f"Quirks tables not loaded: {', '.join(missing_tables)}")
            return
        
        # Get the CURRENT item (which may already have enhancements)
        current_item_name = self.current_item['name']
        
        # Apply FRESH Quirks enhancement to the current item
        enhanced_item, processing_log = self.apply_manual_quirks_enhancement(current_item_name)
        
        # Update current item with new enhancement and increment counter
        self.current_item['name'] = enhanced_item
        self.current_item['quirks_count'] += 1
        
        # Display results
        self.result_text.insert(tk.END, "\n" + "="*60 + "\n")
        self.insert_formatted_text(f"🎭 **QUIRKS ENHANCEMENT #{self.current_item['quirks_count']} APPLIED** 🎭\n", "title")
        self.result_text.insert(tk.END, "="*60 + "\n\n")
        
        self.result_text.insert(tk.END, f"🎯 Item Before: {current_item_name}\n")
        self.result_text.insert(tk.END, f"📈 Quirks Count: {self.current_item['quirks_count']}/3 maximum\n")
        self.result_text.insert(tk.END, f"📋 Quirks Processing Log:\n")
        for i, log_entry in enumerate(processing_log, 1):
            self.result_text.insert(tk.END, f"   {i}. {log_entry}\n")
        
        self.result_text.insert(tk.END, f"\n")
        self.insert_formatted_text(f"🎭 **NEW QUIRKY RESULT: {enhanced_item}** 🎭\n\n", "humorous")
        
        # Show remaining enhancement capacity
        remaining_ee = 3 - self.current_item['ee_count']
        remaining_quirks = 3 - self.current_item['quirks_count']
        
        if remaining_quirks > 0:
            self.result_text.insert(tk.END, f"🎭 {remaining_quirks} more quirks enhancements available!\n")
        else:
            self.result_text.insert(tk.END, f"🚫 Maximum quirks enhancements (3) reached!\n")
            
        if remaining_ee > 0:
            self.result_text.insert(tk.END, f"⭐ {remaining_ee} EE enhancements still available!\n")
        else:
            self.result_text.insert(tk.END, f"🚫 Maximum EE enhancements (3) reached!\n")
            
        self.result_text.insert(tk.END, f"🎲 Or generate a new item to start fresh.\n\n")
        
        # Update button states after applying enhancement
        if self.current_item['ee_count'] >= 3:
            self.ee_enhance_btn.config(state=tk.DISABLED)
        if self.current_item['quirks_count'] >= 3:
            self.quirks_enhance_btn.config(state=tk.DISABLED)
        
        self.result_text.see(tk.END)
        """Manually apply EE enhancement to any item"""
        if applied_enhancements is None:
            applied_enhancements = []
        
        processing_log = []
        
        # Check if we can add more enhancements
        if len(applied_enhancements) >= max_enhancements:
            processing_log.append(f"🚫 Max enhancements ({max_enhancements}) reached")
            return base_item_name, processing_log, applied_enhancements
        
        # Apply EE enhancement
        enhanced_item, ee_log, updated_enhancements = self.process_enchanted_enhancement(
            base_item_name, applied_enhancements, max_enhancements
        )
        processing_log.extend(ee_log)
        
        return enhanced_item, processing_log, updated_enhancements
    
    def roll_for_base_item(self, source_table, applied_enhancements):
        """Roll same table for base item"""
        log = []
        enhancement_chain = []  # Track all enhancements in the chain
        
        if source_table not in self.item_tables:
            log.append(f"⚠️ Source table {source_table} not available")
            return "Unknown Item", log
        
        table_items = self.item_tables[source_table]['items']
        if not table_items:
            log.append(f"⚠️ Source table {source_table} is empty")
            return "Unknown Item", log
        
        attempts = 0
        max_attempts = 10
        
        while attempts < max_attempts:
            base_item_data = random.choice(table_items)
            base_roll = random.randint(base_item_data['roll_from'], base_item_data['roll_to'])
            base_name = base_item_data['name']
            
            log.append(f"   → Base item roll: {base_roll} → {base_name}")
            
            # If base item also has enhancements, process it first
            if self.has_enhancement_symbols(base_name) or self.is_unique_artifact(base_name):
                log.append(f"   → Base item has enhancements, processing...")
                
                # Parse the current enhancement and add to chain
                symbols = self.parse_enhancement_symbols(base_name)
                clean_name = symbols['base_name']
                enhancement_chain.append(clean_name)
                
                # Process the enhancement symbols
                if symbols['reroll']:
                    # Recursive call to get more enhancements
                    processed_base, base_process_log = self.roll_for_base_item(source_table, applied_enhancements.copy())
                    log.extend([f"      {line}" for line in base_process_log])
                    
                    # If the processed base contains multiple parts, add them all
                    if " + " in processed_base:
                        parts = processed_base.split(" + ")
                        enhancement_chain.extend(parts)
                    else:
                        enhancement_chain.append(processed_base)
                
                # Build the full enhancement chain
                final_result = " + ".join(enhancement_chain)
                return final_result, log
            else:
                return base_name, log
            
            attempts += 1
        
        # Fallback
        log.append(f"⚠️ Too many enhancement loops, using simple item")
        simple_items = [item for item in table_items if not self.has_enhancement_symbols(item['name'])]
        if simple_items:
            fallback = random.choice(simple_items)
            return fallback['name'], log
        else:
            return table_items[0]['name'], log
    
    def process_weapon_enhancement(self, base_item, applied_enhancements):
        """Process weapon enhancement ($)"""
        log = [f"💰 Weapon Enhancement triggered for: {base_item}"]
        
        if 'S2' not in self.item_tables:
            log.append("⚠️ S2 table not available")
            return base_item, log
        
        s2_items = self.item_tables['S2']['items']
        s2_item = random.choice(s2_items)
        s2_roll = random.randint(s2_item['roll_from'], s2_item['roll_to'])
        log.append(f"   → S2 Enhancement roll: {s2_roll} → {s2_item['name']}")
        
        enhanced_name = f"{base_item} + {s2_item['name']}"
        log.append(f"🔗 Weapon enhanced: {enhanced_name}")
        return enhanced_name, log
    
    def process_enchanted_enhancement(self, base_item, applied_enhancements, max_enhancements):
        """Process enchanted enhancement (#)"""
        log = [f"⭐ Enchanted Enhancement for: {base_item}"]
        
        if 'EE' not in self.item_tables:
            log.append("⚠️ EE table not available")
            return base_item, log, applied_enhancements
        
        if len(applied_enhancements) >= max_enhancements:
            log.append(f"🚫 Max enhancements reached")
            return base_item, log, applied_enhancements
        
        ee_items = self.item_tables['EE']['items']
        if not ee_items:
            log.append("⚠️ EE table is empty")
            return base_item, log, applied_enhancements
            
        ee_item = random.choice(ee_items)
        ee_roll = random.randint(ee_item['roll_from'], ee_item['roll_to'])
        log.append(f"   → EE roll: {ee_roll} → {ee_item['name']}")
        
        # Process the EE result (it might have its own symbols)
        if self.has_enhancement_symbols(ee_item['name']) or self.is_unique_artifact(ee_item['name']):
            processed_enhancement, ee_process_log, applied_enhancements = self.process_enhanced_item(ee_item['name'], 'EE', applied_enhancements, max_enhancements)
            log.extend([f"   {line}" for line in ee_process_log])
            
            # If processing returned empty string (failed racial enhancement), don't add it
            if processed_enhancement:
                enhanced_name = f"{base_item} + {processed_enhancement}"
            else:
                enhanced_name = base_item
        else:
            enhanced_name = f"{base_item} + {ee_item['name']}"
        
        log.append(f"🔗 EE enhanced: {enhanced_name}")
        return enhanced_name, log, applied_enhancements
    
    def process_aquatic_enhancement(self, base_item):
        """Process aquatic enhancement (%)"""
        log = [f"🌊 Aquatic Enhancement for: {base_item}"]
        
        if 'AE' not in self.item_tables:
            log.append("⚠️ AE table not available")
            return base_item, log
        
        ae_items = self.item_tables['AE']['items']
        ae_item = random.choice(ae_items)
        ae_roll = random.randint(ae_item['roll_from'], ae_item['roll_to'])
        log.append(f"   → AE roll: {ae_roll} → {ae_item['name']}")
        
        enhanced_name = f"{base_item} + {ae_item['name']}"
        log.append(f"🔗 Aquatic enhanced: {enhanced_name}")
        return enhanced_name, log
    
    def process_quirks_enhancement(self, base_item):
        """Process quirks enhancement (@)"""
        log = [f"🎭 Quirks Enhancement for: {base_item}"]
        
        if 'QP' not in self.item_tables or 'QE' not in self.item_tables:
            log.append("⚠️ QP or QE table not available")
            return base_item, log
        
        # Roll QP for number of quirks
        qp_items = self.item_tables['QP']['items']
        qp_item = random.choice(qp_items)
        qp_roll = random.randint(qp_item['roll_from'], qp_item['roll_to'])
        log.append(f"   → QP roll: {qp_roll} → {qp_item['name']}")
        
        # Determine number of quirks
        quirk_count = 1
        quirks_text = qp_item['name'].lower()
        if 'one quirk' in quirks_text:
            quirk_count = 1
        elif 'two quirk' in quirks_text:
            quirk_count = 2
        elif 'three quirk' in quirks_text:
            quirk_count = 3
        
        # Roll QE for each quirk
        quirks = []
        qe_items = self.item_tables['QE']['items']
        for i in range(quirk_count):
            qe_item = random.choice(qe_items)
            qe_roll = random.randint(qe_item['roll_from'], qe_item['roll_to'])
            quirks.append(qe_item['name'])
            log.append(f"   → QE Quirk {i+1}: {qe_roll} → {qe_item['name']}")
        
        quirk_text = " | ".join(quirks)
        enhanced_name = f"{base_item} with Quirks[{quirk_text}]"
        log.append(f"🔗 Quirky: {enhanced_name}")
        return enhanced_name, log
    
    def process_racial_enhancement(self, base_item):
        """Process racial enhancement (&)"""
        log = [f"👥 Racial Enhancement for: {base_item}"]
        
        if 'RE' not in self.item_tables:
            log.append("⚠️ RE table not loaded - check if RE_Table.csv exists")
            log.append(f"📋 Available tables: {list(self.item_tables.keys())}")
            return base_item, log
        
        re_items = self.item_tables['RE']['items']
        if not re_items:
            log.append("⚠️ RE table is loaded but contains 0 items")
            log.append(f"📋 RE table info: {self.item_tables['RE']}")
            return base_item, log
            
        re_item = random.choice(re_items)
        re_roll = random.randint(re_item['roll_from'], re_item['roll_to'])
        
        # Get the race name from the RE table item and clean it
        race_name = re_item['name'].replace('^', '').strip()  # Remove ^ symbol from race name
        log.append(f"   → RE roll: {re_roll} → {race_name}")
        
        # Create enhanced name with racial designation - just use the race name
        enhanced_name = f"{race_name}"
        log.append(f"🔗 Racial enhanced: {enhanced_name}")
        return enhanced_name, log
    
    def is_weapon_enchantment(self, item_name):
        """Check if item ends with dollar sign for weapon enhancement"""
        return item_name.strip().endswith('$')
    
    def select_armor_table(self):
        """Always return R1 to start armor progression"""
        return 'R1'
    def select_weapon_table(self):
        """Always return S1 to start weapon progression"""
        return 'S1'
    def get_main_category_from_table1(self, roll):
        """Get category from Table 1 based on d100 roll"""
        if '1' not in self.item_tables:
            return self.get_fallback_category(roll)
        
        table1_items = self.item_tables['1']['items']
        
        for item in table1_items:
            roll_range = str(item['name']).strip()
            category = item.get('Magical Item Category', '').strip()
            
            if not category:
                continue
                
            if roll_range == "20-Jan":
                if 1 <= roll <= 20:
                    return category
            elif roll_range == "78-00":
                if 78 <= roll <= 100:
                    return category
            elif '-' in roll_range:
                parts = roll_range.split('-')
                if len(parts) == 2:
                    try:
                        range_start, range_end = int(parts[0]), int(parts[1])
                        if range_start <= roll <= range_end:
                            return category
                    except ValueError:
                        continue
            else:
                try:
                    if int(roll_range) == roll:
                        return category
                except ValueError:
                    continue
        
        return self.get_fallback_category(roll)
    
    def get_fallback_category(self, roll):
        """Fallback category mapping if Table 1 fails"""
        if roll <= 20: return "Magical Liquids"
        elif roll <= 35: return "Scrolls"
        elif roll <= 40: return "Rings"
        elif roll == 41: return "Rods"
        elif roll == 42: return "Staves"
        elif roll <= 45: return "Wands"
        elif roll == 46: return "Books"
        elif roll <= 48: return "Gems & Jewelry"
        elif roll <= 50: return "Clothing"
        elif roll <= 52: return "Boots & Gloves"
        elif roll == 53: return "Girdles & Helmets"
        elif roll <= 55: return "Bags & Bottles"
        elif roll == 56: return "Dust & Stones"
        elif roll == 57: return "Household Items"
        elif roll == 58: return "Musical Instruments"
        elif roll <= 60: return "Weird Stuff"
        elif roll == 61: return "Humorous Items"
        elif roll <= 77: return "Armor and Shields"
        else: return "Weapons"
    
    def get_category_items(self, category_name):
        """Get items for a category"""
        if "🎲 Random" in category_name:
            return None, None
        elif "🌟 Legendary Artifacts" in category_name:
            if 'T' in self.item_tables:
                return self.item_tables['T']['items'], 'T'
            else:
                return [], 'T (Missing)'
        elif "🛡️ Armor and Shields" in category_name or "Armor and Shields" in category_name:
            table_id = self.select_armor_table()
            if table_id in self.item_tables:
                return self.item_tables[table_id]['items'], table_id
            else:
                armor_items = []
                for tid in ['R1', 'R2', 'R3']:
                    if tid in self.item_tables:
                        armor_items.extend(self.item_tables[tid]['items'])
                return armor_items, 'R1-R3'
        elif "⚔️ Weapons" in category_name or "Weapons" in category_name:
            table_id = self.select_weapon_table()
            if table_id in self.item_tables:
                return self.item_tables[table_id]['items'], table_id
            else:
                weapon_items = []
                for tid in ['S1', 'S2', 'S3']:
                    if tid in self.item_tables:
                        weapon_items.extend(self.item_tables[tid]['items'])
                return weapon_items, 'S1-S3'
        else:
            if '(' in category_name and ')' in category_name:
                base_category = category_name.split('(')[0].strip()
                base_category = ''.join(char for char in base_category if char.isalnum() or char.isspace() or char in ['&']).strip()
            else:
                base_category = category_name
            
            category_items = []
            used_tables = []
            for table_id, table_data in self.item_tables.items():
                if table_data['category'] == base_category:
                    category_items.extend(table_data['items'])
                    used_tables.append(table_id)
            
            table_desc = '+'.join(used_tables) if len(used_tables) > 1 else (used_tables[0] if used_tables else 'Unknown')
            return category_items, table_desc
    
    def get_item_color_tag(self, item):
        """Determine the color tag for an item"""
        category = item.get('category', '').lower()
        item_name = item['name'].lower()
        
        is_enhanced = any(keyword in item_name for keyword in [
            '+', 'enhanced', 'magical', 'enchanted', 'cursed', 'blessed', 
            'holy', 'unholy', 'legendary', 'artifact', 'relic', 'ancient'
        ])
        
        if item.get('table') == 'T':
            return "legendary"
        
        if is_enhanced:
            return "enhanced"
        
        if 'weapon' in category:
            return "weapons"
        elif 'armor' in category and 'shields' in category:
            return "armor"
        elif 'liquid' in category or 'potion' in category:
            return "potions"
        elif 'scroll' in category or 'book' in category:
            return "scrolls"
        elif 'ring' in category or 'gem' in category or 'jewelry' in category:
            return "jewelry"
        elif 'wand' in category or 'staff' in category or 'staves' in category or 'rod' in category:
            return "implements"
        elif 'clothing' in category or 'boots' in category or 'gloves' in category or 'girdles' in category or 'helmet' in category:
            return "clothing"
        elif 'bag' in category or 'bottle' in category:
            return "containers"
        elif 'humorous' in category:
            return "humorous"
        else:
            return "misc"
    
    def format_item_result(self, item, is_final=False):
        """Format item results with discovery text and color coding"""
        category = item.get('category', '').lower()
        item_name = item['name'].lower()
        
        is_enhanced = any(keyword in item_name for keyword in [
            '+', 'enhanced', 'magical', 'enchanted', 'cursed', 'blessed', 
            'holy', 'unholy', 'legendary', 'artifact', 'relic', 'ancient'
        ])
        
        if 'weapon' in category:
            icon = "⚔️"
            if is_enhanced:
                discovery_words = ["LEGENDARY BLADE DISCOVERED", "ENCHANTED WEAPON UNEARTHED", "MYSTICAL ARMAMENT REVEALED"]
            else:
                discovery_words = ["WEAPON FOUND", "BLADE DISCOVERED", "ARMAMENT LOCATED"]
        elif 'armor' in category:
            icon = "🛡️"
            if is_enhanced:
                discovery_words = ["LEGENDARY PROTECTION DISCOVERED", "ENCHANTED ARMOR UNEARTHED", "MYSTICAL WARD REVEALED"]
            else:
                discovery_words = ["ARMOR FOUND", "PROTECTION DISCOVERED", "DEFENSIVE GEAR LOCATED"]
        elif 'ring' in category:
            icon = "💍"
            if is_enhanced:
                discovery_words = ["RING OF POWER DISCOVERED", "ENCHANTED BAND UNEARTHED", "MYSTICAL CIRCLET REVEALED"]
            else:
                discovery_words = ["RING FOUND", "BAND DISCOVERED", "CIRCLET LOCATED"]
        elif 'liquid' in category:
            icon = "🧪"
            if is_enhanced:
                discovery_words = ["POWERFUL ELIXIR DISCOVERED", "ENCHANTED BREW UNEARTHED", "MYSTICAL POTION REVEALED"]
            else:
                discovery_words = ["POTION FOUND", "ELIXIR DISCOVERED", "BREW LOCATED"]
        else:
            icon = "✨"
            if is_enhanced:
                discovery_words = ["LEGENDARY ARTIFACT DISCOVERED", "ENCHANTED RELIC UNEARTHED", "MYSTICAL TREASURE REVEALED"]
            else:
                discovery_words = ["MAGIC ITEM FOUND", "TREASURE DISCOVERED", "ARTIFACT LOCATED"]
        
        if is_final:
            if is_enhanced:
                discovery_words = ["🏆 LEGENDARY ARTIFACT UNEARTHED 🏆", "🏆 ULTIMATE TREASURE REVEALED 🏆"]
                icon = "🏆"
            else:
                discovery_words = ["🎯 TREASURE DISCOVERED 🎯", "🎯 MAGIC ITEM FOUND 🎯"]
                icon = "🎯"
        
        discovery_text = random.choice(discovery_words)
        return f"{icon} **{discovery_text}: {item['name']}** {icon}", self.get_item_color_tag(item)
    
    def generate_item_from_category(self, category_items, category_name, max_rerolls=3):
        """Generate an item from a category"""
        all_rolls = []
        final_items = []
        
        for attempt in range(max_rerolls + 1):
            item = random.choice(category_items)
            item_roll = random.randint(item['roll_from'], item['roll_to'])
            
            roll_info = f"Roll {attempt + 1}: {item_roll} → {item['name']}"
            all_rolls.append(roll_info)
            
            if self.is_weapon_enchantment(item['name']):
                all_rolls.append(f"   ↳ ⚔️ Weapon Enhancements$ trigger - rolling ONCE on S3 + ONCE on S2!")
                
                if 'S3' in self.item_tables and len(self.item_tables['S3']['items']) > 0:
                    s3_items = self.item_tables['S3']['items']
                    normal_s3_items = [x for x in s3_items if not self.is_reroll_item(x['name']) and not self.is_weapon_enchantment(x['name'])]
                    if normal_s3_items:
                        s3_item = random.choice(normal_s3_items)
                    else:
                        s3_item = random.choice(s3_items)
                    
                    s3_roll = random.randint(s3_item['roll_from'], s3_item['roll_to'])
                    all_rolls.append(f"   → S3 Special Weapon roll: {s3_roll} → {s3_item['name']}")
                    
                    if 'S2' in self.item_tables and len(self.item_tables['S2']['items']) > 0:
                        s2_items = self.item_tables['S2']['items']
                        s2_item = random.choice(s2_items)
                        s2_roll = random.randint(s2_item['roll_from'], s2_item['roll_to'])
                        all_rolls.append(f"   → S2 Enhancement roll: {s2_roll} → {s2_item['name']}")
                        
                        enhanced_weapon = {
                            'name': f"{s3_item['name']} + {s2_item['name']}",
                            'category': 'Enhanced Special Weapons',
                            'table': 'S3+S2',
                            'roll_from': s3_item['roll_from'],
                            'roll_to': s3_item['roll_to'],
                            'base_weapon': s3_item['name'],
                            'enhancement': s2_item['name']
                        }
                        final_items.append(enhanced_weapon)
                    else:
                        final_items.append(s3_item)
                        all_rolls.append(f"   ↳ ⚠️ S2 table not available, using S3 weapon only")
                else:
                    all_rolls.append(f"   ↳ ⚠️ S3 table not available for Weapon Enhancements$")
                    final_items.append(item)
                
                break
                
            elif self.is_reroll_item(item['name']):
                # Handle enhancement symbols using the new system
                if self.has_enhancement_symbols(item['name']) or self.is_unique_artifact(item['name']):
                    all_rolls.append(f"   ↳ ⭐ Enhancement symbols detected - processing...")
                    final_item_name, processing_log, _ = self.process_enhanced_item(item['name'], item['table'])
                    all_rolls.extend([f"   {log}" for log in processing_log])
                    
                    enhanced_item = {
                        'name': final_item_name,
                        'category': item['category'],
                        'table': item['table'],
                        'roll_from': item['roll_from'],
                        'roll_to': item['roll_to'],
                        'original_name': item['name']
                    }
                    final_items.append(enhanced_item)
                    break
                else:
                    # Old asterisk reroll system for compatibility
                    if attempt < max_rerolls:
                        all_rolls.append(f"   ↳ ⭐ Enhancement trigger - rolling twice MORE on {category_name} table!")
                        
                        for sub_roll in range(2):
                            attempts = 0
                            while attempts < 5:
                                sub_item = random.choice(category_items)
                                sub_item_roll = random.randint(sub_item['roll_from'], sub_item['roll_to'])
                                
                                if not self.is_reroll_item(sub_item['name']) and not self.is_weapon_enchantment(sub_item['name']):
                                    all_rolls.append(f"   → Sub-roll {sub_roll + 1}: {sub_item_roll} → {sub_item['name']}")
                                    final_items.append(sub_item)
                                    break
                                else:
                                    all_rolls.append(f"   → Sub-roll {sub_roll + 1}: {sub_item_roll} → {sub_item['name']} (rerolling...)")
                                    attempts += 1
                            
                            if attempts >= 5:
                                fallback_items = [x for x in category_items if not self.is_reroll_item(x['name']) and not self.is_weapon_enchantment(x['name'])]
                                if fallback_items:
                                    fallback_item = random.choice(fallback_items)
                                else:
                                    fallback_item = random.choice(category_items)
                                all_rolls.append(f"   → Fallback: Using {fallback_item['name']}")
                                final_items.append(fallback_item)
                        
                        break
                    else:
                        all_rolls.append("   ↳ ⚠️ Max rerolls reached - treating as regular item")
                        final_items.append(item)
                        break
            else:
                final_items.append(item)
                
                if item['table'] == 'R1':
                    if item['roll_from'] >= 953:
                        all_rolls.append(f"   R1 Roll: {item['roll_from']}-{item['roll_to']} → {item['name']}")
                        if 'R3' in self.item_tables:
                            r3_items = self.item_tables['R3']['items']
                            r3_item = random.choice(r3_items)
                            r3_roll = random.randint(r3_item['roll_from'], r3_item['roll_to'])
                            all_rolls.append(f"   → R3 Special Armor roll: {r3_roll} → {r3_item['name']}")
                            final_items[-1] = r3_item
                            break
                    elif 'R2' in self.item_tables:
                        r2_items = self.item_tables['R2']['items']
                        r2_item = random.choice(r2_items)
                        r2_roll = random.randint(r2_item['roll_from'], r2_item['roll_to'])
                        all_rolls.append(f"   → R2 Enhancement roll: {r2_roll} → {r2_item['name']}")
                        combined_item = {
                            'name': f"{item['name']} + {r2_item['name']}",
                            'category': item['category'],
                            'table': 'R1+R2',
                            'roll_from': item['roll_from'],
                            'roll_to': item['roll_to']
                        }
                        final_items[-1] = combined_item
                        break
                elif item['table'] == 'S1':
                    if item['roll_from'] >= 975:
                        all_rolls.append(f"   S1 Roll: {item['roll_from']}-{item['roll_to']} → {item['name']}")
                        if 'S3' in self.item_tables:
                            s3_items = self.item_tables['S3']['items']
                            s3_item = random.choice(s3_items)
                            s3_roll = random.randint(s3_item['roll_from'], s3_item['roll_to'])
                            all_rolls.append(f"   → S3 Special Weapon roll: {s3_roll} → {s3_item['name']}")
                            final_items[-1] = s3_item
                            break
                    elif 'S2' in self.item_tables:
                        s2_items = self.item_tables['S2']['items']
                        s2_item = random.choice(s2_items)
                        s2_roll = random.randint(s2_item['roll_from'], s2_item['roll_to'])
                        all_rolls.append(f"   → S2 Enhancement roll: {s2_roll} → {s2_item['name']}")
                        combined_item = {
                            'name': f"{item['name']} + {s2_item['name']}",
                            'category': item['category'],
                            'table': 'S1+S2',
                            'roll_from': item['roll_from'],
                            'roll_to': item['roll_to']
                        }
                        final_items[-1] = combined_item
                        break
                    adjustment_table = 'R2' if item['table'] == 'R1' else 'S2'
                    if adjustment_table in self.item_tables and len(self.item_tables[adjustment_table]['items']) > 0:
                        all_rolls.append(f"   ↳ 🎯 Generic item - rolling on {adjustment_table} for magical properties!")
                        
                        adj_items = self.item_tables[adjustment_table]['items']
                        adj_item = random.choice(adj_items)
                        adj_roll = random.randint(adj_item['roll_from'], adj_item['roll_to'])
                        
                        all_rolls.append(f"   → Adjustment roll: {adj_roll} → {adj_item['name']}")
                        
                        combined_item = {
                            'name': f"{item['name']} + {adj_item['name']}",
                            'category': item['category'],
                            'table': f"{item['table']}+{adjustment_table}",
                            'roll_from': item['roll_from'],
                            'roll_to': item['roll_to'],
                            'adjustment': adj_item['name']
                        }
                        
                        final_items[-1] = combined_item
                    else:
                        all_rolls.append(f"   ↳ ⚠️ Adjustment table {adjustment_table} not found or empty!")
                
                break
        
        return final_items, all_rolls

    def create_gui(self):
        """Create the GUI interface"""
        bg_dark = '#1a0f0a'
        bg_medium = '#2c1810' 
        gold = '#ffd700'
        silver = '#c0c0c0'
        copper = '#cd853f'
        red = '#8b0000'
        green = '#228b22'
        
        self.root.configure(bg=bg_dark)
        
        # Title
        title_frame = tk.Frame(self.root, bg=bg_dark, pady=15)
        title_frame.pack(pady=20, fill=tk.X)
        
        title_label = tk.Label(title_frame, 
                              text="⚔️ 🧙‍♂️ ENHANCED ARCANE TREASURY GENERATOR 🧙‍♂️ ⚔️",
                              font=('Georgia', 20, 'bold'),
                              fg=gold,
                              bg=bg_dark,
                              relief=tk.RAISED,
                              bd=3)
        title_label.pack()
        
        subtitle_label = tk.Label(title_frame,
                                 text="🗝️ Ancient Tables of Wondrous Items • Enhanced Symbols Active • Est. 1974 🗝️",
                                 font=('Georgia', 11, 'italic'),
                                 fg=silver,
                                 bg=bg_dark)
        subtitle_label.pack(pady=(5, 0))
        
        # Separator
        separator_frame = tk.Frame(self.root, bg=copper, height=3)
        separator_frame.pack(fill=tk.X, padx=50, pady=10)
        
        # Status
        self.status_label = tk.Label(self.root,
                                    text=f"📚 {self.total_items} Magical Items • 📜 {len(self.item_tables)} Ancient Tables • ⚡ Enhancement Systems Ready",
                                    font=('Georgia', 10, 'bold'),
                                    fg=green,
                                    bg=bg_dark)
        self.status_label.pack(pady=10)
        
        # Control panel
        control_frame = tk.Frame(self.root, bg=bg_medium, relief=tk.RAISED, bd=2)
        control_frame.pack(pady=20, padx=20, fill=tk.X)
        
        control_title = tk.Label(control_frame,
                                text="🎲 DIVINATION CONTROLS 🎲",
                                font=('Georgia', 14, 'bold'),
                                fg=gold,
                                bg=bg_medium)
        control_title.pack(pady=10)
        
        # Main buttons frame
        button_frame = tk.Frame(control_frame, bg=bg_medium)
        button_frame.pack(pady=15)
        
        self.generate_btn = tk.Button(button_frame,
                                     text="🔮 CONJURE MAGIC ITEM 🔮",
                                     font=('Georgia', 14, 'bold'),
                                     bg='#654321',
                                     fg=gold,
                                     activebackground='#8b4513',
                                     activeforeground=gold,
                                     command=self.generate_item,
                                     padx=25,
                                     pady=12,
                                     relief=tk.RAISED,
                                     bd=3,
                                     cursor='hand2')
        self.generate_btn.pack(side=tk.LEFT, padx=15)
        
        self.reroll_btn = tk.Button(button_frame,
                                   text="🌀 DIVINE AGAIN 🌀",
                                   font=('Georgia', 11, 'bold'),
                                   bg=red,
                                   fg=gold,
                                   activebackground='#a52a2a',
                                   activeforeground=gold,
                                   command=self.reroll_same_table,
                                   padx=15,
                                   pady=10,
                                   relief=tk.RAISED,
                                   bd=2,
                                   cursor='hand2')
        self.reroll_btn.pack(side=tk.LEFT, padx=10)
        
        # NEW: Manual EE Enhancement button
        self.ee_enhance_btn = tk.Button(button_frame,
                                       text="⭐ ADD EE ENHANCEMENT ⭐",
                                       font=('Georgia', 11, 'bold'),
                                       bg='#4a90e2',
                                       fg=gold,
                                       activebackground='#5ba0f2',
                                       activeforeground=gold,
                                       command=self.manual_ee_enhancement,
                                       padx=15,
                                       pady=10,
                                       relief=tk.RAISED,
                                       bd=2,
                                       cursor='hand2',
                                       state=tk.DISABLED)  # Disabled until item is generated
        self.ee_enhance_btn.pack(side=tk.LEFT, padx=10)
        
        # NEW: Manual Quirks Enhancement button
        self.quirks_enhance_btn = tk.Button(button_frame,
                                           text="🎭 ADD QUIRKS 🎭",
                                           font=('Georgia', 11, 'bold'),
                                           bg='#9c27b0',
                                           fg=gold,
                                           activebackground='#ba68c8',
                                           activeforeground=gold,
                                           command=self.manual_quirks_enhancement,
                                           padx=15,
                                           pady=10,
                                           relief=tk.RAISED,
                                           bd=2,
                                           cursor='hand2',
                                           state=tk.DISABLED)  # Disabled until item is generated
        self.quirks_enhance_btn.pack(side=tk.LEFT, padx=10)
        
        self.test_btn = tk.Button(button_frame,
                                 text="🧪 TEST ENHANCEMENTS 🧪",
                                 font=('Georgia', 11, 'bold'),
                                 bg='#4a90e2',
                                 fg=gold,
                                 activebackground='#5ba0f2',
                                 activeforeground=gold,
                                 command=self.test_enhancement_system,
                                 padx=15,
                                 pady=10,
                                 relief=tk.RAISED,
                                 bd=2,
                                 cursor='hand2')
        self.test_btn.pack(side=tk.LEFT, padx=10)
        self.test_btn.pack_forget()
        
        # Category selection
        category_frame = tk.Frame(control_frame, bg=bg_medium)
        category_frame.pack(pady=15)
        
        category_title = tk.Label(category_frame,
                                 text="📖 TOME SELECTION 📖",
                                 font=('Georgia', 12, 'bold'),
                                 fg=copper,
                                 bg=bg_medium)
        category_title.pack(pady=(0, 5))
        
        selection_frame = tk.Frame(category_frame, bg=bg_medium)
        selection_frame.pack()
        
        category_label = tk.Label(selection_frame,
                                 text="🗂️ Category:",
                                 font=('Georgia', 11, 'bold'),
                                 fg=silver,
                                 bg=bg_medium)
        category_label.pack(side=tk.LEFT, padx=(0, 10))
        
        # Create dropdown options
        categories = ["🎲 Random (Table 1 → All Tables)"]
        
        if 'T' in self.item_tables:
            t_count = len(self.item_tables['T']['items'])
            categories.append(f"🌟 Legendary Artifacts (Table T) - {t_count} items")
        
        category_mappings = {
            'Magical Liquids': 'A',
            'Scrolls': 'B', 
            'Rings': 'C',
            'Rods': 'D',
            'Staves': 'E',
            'Wands': 'F',
            'Books': 'G',
            'Gems & Jewelry': 'H',
            'Clothing': 'I',
            'Boots & Gloves': 'J',
            'Girdles & Helmets': 'K',
            'Bags & Bottles': 'L',
            'Dust & Stones': 'M',
            'Household Items': 'N',
            'Musical Instruments': 'O',
            'Weird Stuff': 'P',
            'Humorous Items': 'Q',
            'Armor and Shields': 'R1/R2/R3',
            'Weapons': 'S1/S2/S3'
        }
        
        for category_name in sorted(category_mappings.keys()):
            table_ref = category_mappings[category_name]
            
            item_count = 0
            if category_name in ['Armor and Shields', 'Weapons']:
                if category_name == 'Armor and Shields':
                    for tid in ['R1', 'R2', 'R3']:
                        if tid in self.item_tables:
                            item_count += len(self.item_tables[tid]['items'])
                else:
                    for tid in ['S1', 'S2', 'S3']:
                        if tid in self.item_tables:
                            item_count += len(self.item_tables[tid]['items'])
            else:
                for table_id, table_data in self.item_tables.items():
                    if table_data['category'] == category_name:
                        item_count += len(table_data['items'])
            
            if category_name == 'Armor and Shields':
                categories.append(f"🛡️ {category_name} (Tables {table_ref}) - {item_count} items")
            elif category_name == 'Weapons':
                categories.append(f"⚔️ {category_name} (Tables {table_ref}) - {item_count} items")
            elif 'Magical Liquids' in category_name:
                categories.append(f"🧪 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Scrolls' in category_name:
                categories.append(f"📜 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Rings' in category_name:
                categories.append(f"💍 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Books' in category_name:
                categories.append(f"📚 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Gems' in category_name or 'Jewelry' in category_name:
                categories.append(f"💎 {category_name} (Table {table_ref}) - {item_count} items")
            elif any(word in category_name for word in ['Clothing', 'Boots', 'Gloves', 'Girdles', 'Helmets']):
                categories.append(f"👕 {category_name} (Table {table_ref}) - {item_count} items")
            elif any(word in category_name for word in ['Wand', 'Staves', 'Rods']):
                categories.append(f"🪄 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Bags' in category_name or 'Bottles' in category_name:
                categories.append(f"🎒 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Humorous' in category_name:
                categories.append(f"🤡 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Musical' in category_name:
                categories.append(f"🎵 {category_name} (Table {table_ref}) - {item_count} items")
            elif 'Weird' in category_name:
                categories.append(f"👽 {category_name} (Table {table_ref}) - {item_count} items")
            else:
                categories.append(f"✨ {category_name} (Table {table_ref}) - {item_count} items")
        
        # Initialize dropdown with Random as default
        self.category_var = tk.StringVar(value="🎲 Random (Table 1 → All Tables)")
        
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Fantasy.TCombobox',
                       fieldbackground='#3d2818',
                       background='#654321',
                       foreground='white',
                       arrowcolor='gold')
        
        category_combo = ttk.Combobox(selection_frame,
                                     textvariable=self.category_var,
                                     values=categories,
                                     state="readonly",
                                     width=50,
                                     font=('Georgia', 10),
                                     style='Fantasy.TCombobox')
        category_combo.pack(side=tk.LEFT, padx=5)
        
        # Results
        results_title_frame = tk.Frame(self.root, bg=bg_dark)
        results_title_frame.pack(fill=tk.X, padx=20, pady=(20, 0))
        
        results_title = tk.Label(results_title_frame,
                               text="📜 DIVINATION RESULTS 📜",
                               font=('Georgia', 14, 'bold'),
                               fg=gold,
                               bg=bg_dark)
        results_title.pack()
        
        # Results frame
        result_frame = tk.Frame(self.root, bg=bg_medium, relief=tk.SUNKEN, bd=3)
        result_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Text display
        self.result_text = scrolledtext.ScrolledText(result_frame,
                                                    font=('Consolas', 11),
                                                    bg='#0f0f23',
                                                    fg='#e6d690',
                                                    insertbackground=gold,
                                                    selectbackground='#4a4a4a',
                                                    selectforeground=gold,
                                                    wrap=tk.WORD,
                                                    height=18,
                                                    relief=tk.SUNKEN,
                                                    bd=2,
                                                    padx=10,
                                                    pady=10)
        self.result_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Color-coded text formatting
        self.result_text.tag_config("bold", font=('Consolas', 11, 'bold'), foreground=gold)
        self.result_text.tag_config("italic", font=('Consolas', 11, 'italic'), foreground=silver)
        self.result_text.tag_config("title", font=('Consolas', 14, 'bold'), foreground=gold)
        self.result_text.tag_config("category", font=('Consolas', 10), foreground=copper)
        self.result_text.tag_config("dice", font=('Consolas', 10), foreground='#87CEEB')
        
        # Item type colors (all bold by default)
        self.result_text.tag_config("weapons", font=('Consolas', 12, 'bold'), foreground='#FF6B6B')
        self.result_text.tag_config("armor", font=('Consolas', 12, 'bold'), foreground='#4ECDC4')
        self.result_text.tag_config("potions", font=('Consolas', 12, 'bold'), foreground='#45B7D1')
        self.result_text.tag_config("scrolls", font=('Consolas', 12, 'bold'), foreground='#F9CA24')
        self.result_text.tag_config("jewelry", font=('Consolas', 12, 'bold'), foreground='#F0932B')
        self.result_text.tag_config("implements", font=('Consolas', 12, 'bold'), foreground='#9C88FF')
        self.result_text.tag_config("clothing", font=('Consolas', 12, 'bold'), foreground='#6C5CE7')
        self.result_text.tag_config("containers", font=('Consolas', 12, 'bold'), foreground='#A29BFE')
        self.result_text.tag_config("misc", font=('Consolas', 12, 'bold'), foreground='#FD79A8')
        self.result_text.tag_config("humorous", font=('Consolas', 12, 'bold'), foreground='#00B894')
        self.result_text.tag_config("legendary", font=('Consolas', 14, 'bold'), foreground='#FFD700')
        self.result_text.tag_config("enhanced", font=('Consolas', 12, 'bold'), foreground='#00FFFF')
        
        # Welcome message
        self.insert_formatted_text("🌟 Welcome, brave adventurer, to the Enhanced Arcane Treasury Generator! 🌟\n\n")
        self.insert_formatted_text("📿 **MYSTICAL ENHANCEMENTS FULLY ACTIVATED** 📿\n")
        self.insert_formatted_text("⚡ All Enhancement Symbols: * # % @ & ^ $ **item**\n")
        self.insert_formatted_text("🔮 * = Reroll same table and combine\n") 
        self.insert_formatted_text("⭐ # = Roll Enchanted Enhancements table\n")
        self.insert_formatted_text("🌊 % = Roll Aquatic Enhancement table\n")
        self.insert_formatted_text("🎭 @ = Roll Quirks tables (QP → QE)\n")
        self.insert_formatted_text("👥 & = Roll Racial Enhancement table\n")
        self.insert_formatted_text("🚫 ^ = No duplicates of this enhancement type\n")
        self.insert_formatted_text("💰 $ = Weapon Enhancement (S2 table)\n")
        self.insert_formatted_text("✨ **item** = Unique artifacts (no processing)\n\n")
        
        enhancement_count = sum(1 for table in ['EE', 'QE', 'QP', 'AE', 'RE'] if table in self.item_tables)
        self.insert_formatted_text("🔮 **Ready to generate authentic enhanced magical items!** 🔮\n\n")
        self.insert_formatted_text(f"📚 **Arcane Database:** {self.total_items:,} magical items across {len(self.item_tables)} mystical tables\n")
        self.insert_formatted_text(f"🎯 **Enhancement Tables:** {enhancement_count}/5 systems loaded\n")
        self.insert_formatted_text("⭐ **NEW FEATURE:** Manual EE Enhancement - enhance ANY item with Enchanted Enhancements!\n")
        self.insert_formatted_text("🎭 **NEW FEATURE:** Manual Quirks Enhancement - add quirks to ANY item!\n\n")
        self.insert_formatted_text("🌙 May the ancient symbols guide your rolls, adventurer! 🌙\n")
        
        # Add hover effects
        self.add_hover_effects()
    
    def add_hover_effects(self):
        """Add hover effects to buttons"""
        def on_enter_main(e):
            self.generate_btn.config(bg='#8b4513', fg='#ffffff')
        
        def on_leave_main(e):
            self.generate_btn.config(bg='#654321', fg='#ffd700')
            
        def on_enter_reroll(e):
            self.reroll_btn.config(bg='#a52a2a', fg='#ffffff')
        
        def on_leave_reroll(e):
            self.reroll_btn.config(bg='#8b0000', fg='#ffd700')
            
        def on_enter_ee(e):
            if self.ee_enhance_btn['state'] == tk.NORMAL:
                self.ee_enhance_btn.config(bg='#5ba0f2', fg='#ffffff')
        
        def on_leave_ee(e):
            if self.ee_enhance_btn['state'] == tk.NORMAL:
                self.ee_enhance_btn.config(bg='#4a90e2', fg='#ffd700')
                
        def on_enter_quirks(e):
            if self.quirks_enhance_btn['state'] == tk.NORMAL:
                self.quirks_enhance_btn.config(bg='#ba68c8', fg='#ffffff')
        
        def on_leave_quirks(e):
            if self.quirks_enhance_btn['state'] == tk.NORMAL:
                self.quirks_enhance_btn.config(bg='#9c27b0', fg='#ffd700')
            if self.ee_enhance_btn['state'] == tk.NORMAL:
                self.ee_enhance_btn.config(bg='#5ba0f2', fg='#ffffff')
        
        def on_leave_ee(e):
            if self.ee_enhance_btn['state'] == tk.NORMAL:
                self.ee_enhance_btn.config(bg='#4a90e2', fg='#ffd700')
            
        def on_enter_test(e):
            self.test_btn.config(bg='#5ba0f2', fg='#ffffff')
        
        def on_leave_test(e):
            self.test_btn.config(bg='#4a90e2', fg='#ffd700')
        
        self.generate_btn.bind("<Enter>", on_enter_main)
        self.generate_btn.bind("<Leave>", on_leave_main)
        self.reroll_btn.bind("<Enter>", on_enter_reroll)
        self.reroll_btn.bind("<Leave>", on_leave_reroll)
        self.ee_enhance_btn.bind("<Enter>", on_enter_ee)
        self.ee_enhance_btn.bind("<Leave>", on_leave_ee)
        self.quirks_enhance_btn.bind("<Enter>", on_enter_quirks)
        self.quirks_enhance_btn.bind("<Leave>", on_leave_quirks)
        self.test_btn.bind("<Enter>", on_enter_test)
        self.test_btn.bind("<Leave>", on_leave_test)
    
    def insert_formatted_text(self, text, tag=None):
        """Insert text with formatting and color tags"""
        if '**' in text and tag and tag in ["weapons", "armor", "potions", "scrolls", "jewelry", "implements", "clothing", "containers", "misc", "humorous", "legendary", "enhanced"]:
            # For colored item text, don't split on ** since the color tags already include bold
            self.result_text.insert(tk.END, text.replace('**', ''), tag)
        elif '**' in text:
            # Regular bold formatting
            parts = text.split('**')
            for i, part in enumerate(parts):
                if i % 2 == 1:  # Odd indices are bold
                    self.result_text.insert(tk.END, part, "bold")
                else:
                    if tag:
                        self.result_text.insert(tk.END, part, tag)
                    else:
                        self.result_text.insert(tk.END, part)
        else:
            # No bold formatting, just apply the tag
            self.result_text.insert(tk.END, text, tag)

    def manual_ee_enhancement(self):
        """Manually apply EE enhancement to the current item"""        
        print("DEBUG: EE Enhancement button clicked")
        
        if not self.current_item['available']:
            print("DEBUG: No current item available")
            messagebox.showwarning("No Item Available", 
                                 "Please generate an item first before applying EE enhancement!")
            return
        
        # Check if max EE enhancements reached (3 max)
        if self.current_item['ee_count'] >= 3:
            messagebox.showwarning("Max EE Enhancements Reached", 
                                 "This item already has 3 EE enhancements (maximum allowed)!")
            return
        
        if 'EE' not in self.item_tables:
            print("DEBUG: EE table not found")
            messagebox.showerror("EE Table Missing", 
                               "Enchanted Enhancements table (EE_Table.csv) is not loaded!")
            return
        
        print(f"DEBUG: Current item: {self.current_item}")
        
        # Get the CURRENT item (which may already have enhancements)
        current_item_name = self.current_item['name']
        print(f"DEBUG: Current item name: {current_item_name}")
        
        try:
            # Apply FRESH EE enhancement to the current item
            enhanced_item, processing_log, applied_enhancements = self.apply_manual_ee_enhancement(current_item_name)
            print(f"DEBUG: Enhanced item: {enhanced_item}")
            
            # Update current item with new enhancement and increment counter
            self.current_item['name'] = enhanced_item
            self.current_item['ee_count'] += 1
            
            # Display results
            self.result_text.insert(tk.END, "\n" + "="*60 + "\n")
            self.insert_formatted_text(f"⭐ **EE ENHANCEMENT #{self.current_item['ee_count']} APPLIED** ⭐\n", "title")
            self.result_text.insert(tk.END, "="*60 + "\n\n")
            
            self.result_text.insert(tk.END, f"🎯 Item Before: {current_item_name}\n")
            self.result_text.insert(tk.END, f"📈 EE Count: {self.current_item['ee_count']}/3 maximum\n")
            self.result_text.insert(tk.END, f"📋 Enhancement Processing Log:\n")
            for i, log_entry in enumerate(processing_log, 1):
                self.result_text.insert(tk.END, f"   {i}. {log_entry}\n")
            
            self.result_text.insert(tk.END, f"\n")
            self.insert_formatted_text(f"✨ **NEW ENHANCED RESULT: {enhanced_item}** ✨\n\n", "enhanced")
            
            self.result_text.insert(tk.END, f"🔧 Applied Enhancements: {applied_enhancements}\n")
            
            # Show remaining enhancement capacity
            remaining_ee = 3 - self.current_item['ee_count']
            remaining_quirks = 3 - self.current_item['quirks_count']
            
            if remaining_ee > 0:
                self.result_text.insert(tk.END, f"⭐ {remaining_ee} more EE enhancements available!\n")
            else:
                self.result_text.insert(tk.END, f"🚫 Maximum EE enhancements (3) reached!\n")
                
            if remaining_quirks > 0:
                self.result_text.insert(tk.END, f"🎭 {remaining_quirks} quirks enhancements still available!\n")
            else:
                self.result_text.insert(tk.END, f"🚫 Maximum quirks enhancements (3) reached!\n")
                
            self.result_text.insert(tk.END, f"🎲 Or generate a new item to start fresh.\n\n")
            
            # Update button states after applying enhancement
            if self.current_item['ee_count'] >= 3:
                self.ee_enhance_btn.config(state=tk.DISABLED)
            if self.current_item['quirks_count'] >= 3:
                self.quirks_enhance_btn.config(state=tk.DISABLED)
            
            self.result_text.see(tk.END)
            print("DEBUG: EE Enhancement completed successfully")
            
        except Exception as e:
            print(f"DEBUG: Error in EE enhancement: {str(e)}")
            import traceback
            traceback.print_exc()
            messagebox.showerror("Enhancement Error", f"An error occurred: {str(e)}")

    def generate_item(self):
        """Generate a random magic item"""
        if not self.all_items:
            self.result_text.insert(tk.END, "\n❌ No items loaded! Check your CSV files.\n")
            return
        
        selected_category = self.category_var.get()
        
        if selected_category.startswith("🎲 Random"):
            main_table_roll = random.randint(1, 100)
            category = self.get_main_category_from_table1(main_table_roll)
            category_items, table_used = self.get_category_items(category)
            final_items, all_rolls = self.generate_item_from_category(category_items, category)
            
            dice_info = f"🎲 Table 1 Roll: {main_table_roll} → {category} (Table {table_used})\n"
            dice_info += f"🎲 {category} Rolls:\n"
            for roll in all_rolls:
                dice_info += f"   {roll}\n"
                
            actual_category = category
            actual_items = category_items
            
        else:
            category_items, table_used = self.get_category_items(selected_category)
            
            if category_items:
                if "🌟 Legendary Artifacts" in selected_category:
                    clean_category = "Legendary Artifacts"
                elif '(' in selected_category:
                    clean_category = selected_category.split('(')[0].strip()
                    clean_category = ''.join(char for char in clean_category if char.isalpha() or char.isspace()).strip()
                else:
                    clean_category = selected_category
                
                final_items, all_rolls = self.generate_item_from_category(category_items, clean_category)
                
                dice_info = f"🎲 {clean_category} Rolls (Table {table_used}):\n"
                for roll in all_rolls:
                    dice_info += f"   {roll}\n"
                    
                actual_category = clean_category
                actual_items = category_items
            else:
                self.result_text.insert(tk.END, f"\n❌ No items found in category: {selected_category}\n")
                return
        
        # Display results
        self.result_text.insert(tk.END, "\n" + "="*60 + "\n")
        self.insert_formatted_text(f"🔮 **MYSTICAL DIVINATION COMPLETE** 🔮\n", "title")
        self.result_text.insert(tk.END, "="*60 + "\n\n")
        
        self.result_text.insert(tk.END, dice_info + "\n", "dice")
        
        if len(final_items) == 1:
            item = final_items[0]
            
            # Store current item for EE enhancement
            self.current_item = {
                'name': item['name'],
                'original_name': item['name'],  # Store original for fresh EE enhancements
                'category': item['category'],
                'table': item['table'],
                'available': True,
                'ee_count': 0,      # Reset enhancement counters
                'quirks_count': 0
            }
            
            # Enable EE enhancement button
            # Enable buttons based on remaining enhancement capacity
            if self.current_item['ee_count'] < 3:
                self.ee_enhance_btn.config(state=tk.NORMAL)
            else:
                self.ee_enhance_btn.config(state=tk.DISABLED)
                
            if self.current_item['quirks_count'] < 3:
                self.quirks_enhance_btn.config(state=tk.NORMAL)
            else:
                self.quirks_enhance_btn.config(state=tk.DISABLED)
            # Enable Quirks enhancement button
            self.quirks_enhance_btn.config(state=tk.NORMAL)
            
            self.last_generation = {
                'category': actual_category,
                'table_id': item['table'],
                'items': actual_items,
                'available': True
            }
            
            if "🌟 Legendary Artifacts" in selected_category or actual_category == "Legendary Artifacts":
                self.result_text.insert(tk.END, f"🌟 Category: LEGENDARY ARTIFACTS\n", "category")
                self.result_text.insert(tk.END, f"📋 Table: T (Ancient Artifacts of Power)\n", "category") 
                self.result_text.insert(tk.END, f"🎲 Range: {item['roll_from']}-{item['roll_to']}\n", "category")
                self.result_text.insert(tk.END, f"⚡ Power Level: MAXIMUM\n\n", "category")
                
                legendary_discoveries = [
                    "🌟 ARTIFACT OF COSMIC POWER UNEARTHED 🌟",
                    "🌟 LEGENDARY RELIC OF THE ANCIENTS DISCOVERED 🌟", 
                    "🌟 ULTIMATE TREASURE OF THE AGES REVEALED 🌟",
                    "🌟 MYTHICAL ARTIFACT OF UNTOLD POWER FOUND 🌟"
                ]
                legendary_text = random.choice(legendary_discoveries)
                self.insert_formatted_text(f"{legendary_text}: {item['name']}\n\n", "legendary")
                
                self.result_text.insert(tk.END, f"💎 Behold! A true artifact of legend has been revealed!\n")
                self.result_text.insert(tk.END, f"🔮 Use '🌀 DIVINE AGAIN' to discover another legendary relic!\n")
                self.result_text.insert(tk.END, f"⭐ Use 'ADD EE ENHANCEMENT' to further enhance this legendary artifact!\n\n")
            else:
                self.result_text.insert(tk.END, f"📖 Category: {item['category']}\n", "category")
                self.result_text.insert(tk.END, f"📋 Table: {item['table']}\n", "category")
                self.result_text.insert(tk.END, f"🎲 Range: {item['roll_from']}-{item['roll_to']}\n\n", "category")
                
                formatted_item, color_tag = self.format_item_result(item, is_final=True)
                self.insert_formatted_text(f"{formatted_item}\n\n", color_tag)
                
                self.result_text.insert(tk.END, f"💡 Seek different treasure? Use '🌀 DIVINE AGAIN' for another {item['category']} item!\n")
                self.result_text.insert(tk.END, f"⭐ Want to enhance this item? Use 'ADD EE ENHANCEMENT' to apply Enchanted Enhancements!\n\n")
        else:
            # Multiple items - store the first one for enhancement
            if final_items:
                self.current_item = {
                    'name': final_items[0]['name'],
                    'original_name': final_items[0]['name'],  # Store original for fresh EE enhancements
                    'category': final_items[0]['category'],
                    'table': final_items[0]['table'],
                    'available': True,
                    'ee_count': 0,      # Reset enhancement counters
                    'quirks_count': 0
                }
                # Enable buttons based on remaining enhancement capacity
                if self.current_item['ee_count'] < 3:
                    self.ee_enhance_btn.config(state=tk.NORMAL)
                else:
                    self.ee_enhance_btn.config(state=tk.DISABLED)
                    
                if self.current_item['quirks_count'] < 3:
                    self.quirks_enhance_btn.config(state=tk.NORMAL)
                else:
                    self.quirks_enhance_btn.config(state=tk.DISABLED)
                self.quirks_enhance_btn.config(state=tk.NORMAL)
            
            self.insert_formatted_text(f"⚡ **ENHANCEMENT CASCADE TRIGGERED** ⚡\n\n", "title")
            self.result_text.insert(tk.END, f"🔗 Combined magical energies detected:\n")
            for i, item in enumerate(final_items, 1):
                formatted_item, color_tag = self.format_item_result(item)
                self.insert_formatted_text(f"   {i}. {formatted_item}\n", color_tag)
            
            self.result_text.insert(tk.END, f"\n🧙‍♂️ **DM's Forge:** Combine these {len(final_items)} magical essences into ONE ultimate artifact!\n")
            self.result_text.insert(tk.END, f"⭐ **Enhancement Available:** You can enhance the first item ({final_items[0]['name']}) with EE!\n\n")
            
            if final_items:
                self.last_generation = {
                    'category': actual_category,
                    'table_id': final_items[0]['table'].split('+')[0],
                    'items': actual_items,
                    'available': True
                }
        
        self.result_text.see(tk.END)
    
    def reroll_same_table(self):
        """Reroll on the same table"""
        if not self.last_generation['available']:
            self.result_text.insert(tk.END, "\n❌ No previous generation to reroll! Generate an item first.\n\n")
            self.result_text.see(tk.END)
            return
        
        category = self.last_generation['category']
        table_id = self.last_generation['table_id']
        category_items = self.last_generation['items']
        
        self.result_text.insert(tk.END, "\n" + "="*60 + "\n")
        self.result_text.insert(tk.END, f"🔄 REROLLING ON SAME TABLE 🔄\n")
        self.result_text.insert(tk.END, "="*60 + "\n\n")
        self.result_text.insert(tk.END, f"🎯 Rerolling on: {category} (Table {table_id})\n")
        self.result_text.insert(tk.END, f"📊 Available items: {len(category_items)}\n\n")
        
        final_items, all_rolls = self.generate_item_from_category(category_items, category)
        
        dice_info = f"🎲 {category} Reroll:\n"
        for roll in all_rolls:
            dice_info += f"   {roll}\n"
        
        self.result_text.insert(tk.END, f"{dice_info}\n")
        
        if len(final_items) == 1:
            item = final_items[0]
            
            # Update current item for EE enhancement
            self.current_item = {
                'name': item['name'],
                'original_name': item.get('original_name', item['name']),  # Preserve original if it exists
                'category': item['category'],
                'table': item['table'],
                'available': True,
                'ee_count': 0,      # Reset enhancement counters for rerolls
                'quirks_count': 0
            }
            self.ee_enhance_btn.config(state=tk.NORMAL)
            
            self.result_text.insert(tk.END, f"📜 Category: {item['category']}\n")
            self.result_text.insert(tk.END, f"🎯 Table: {item['table']}\n")
            self.result_text.insert(tk.END, f"🎲 Range: {item['roll_from']}-{item['roll_to']}\n\n")
            self.insert_formatted_text(f"✨ **REROLL RESULT: {item['name']}** ✨\n\n", self.get_item_color_tag(item))
            
            self.last_generation['table_id'] = item['table']
            
            self.result_text.insert(tk.END, f"💡 Still not right? Click '🌀 DIVINE AGAIN' again!\n")
            self.result_text.insert(tk.END, f"⭐ Want to enhance? Use 'ADD EE ENHANCEMENT'!\n\n")
        else:
            # Multiple items - update current item to first one
            if final_items:
                self.current_item = {
                    'name': final_items[0]['name'],
                    'original_name': final_items[0].get('original_name', final_items[0]['name']),  # Preserve original
                    'category': final_items[0]['category'],
                    'table': final_items[0]['table'],
                    'available': True
                }
                self.ee_enhance_btn.config(state=tk.NORMAL)
            
            self.result_text.insert(tk.END, f"🔄 ENHANCED REROLL RESULT:\n\n")
            for i, item in enumerate(final_items, 1):
                self.insert_formatted_text(f"   ✨ **{i}. {item['name']}**\n", self.get_item_color_tag(item))
            self.result_text.insert(tk.END, f"\n💡 Combine these {len(final_items)} items into ONE enhanced item!\n")
            self.result_text.insert(tk.END, f"⭐ **Enhancement Available:** You can enhance the first item with EE!\n\n")
        
        self.result_text.see(tk.END)
    
    def test_enhancement_system(self):
        """Test the enhancement system with real items from random tables"""
        self.result_text.insert(tk.END, "\n" + "="*80 + "\n")
        self.result_text.insert(tk.END, "🧪 ENHANCEMENT SYSTEM TEST 🧪\n")
        self.result_text.insert(tk.END, "="*80 + "\n\n")
        
        self.result_text.insert(tk.END, "📋 **ENHANCED SYMBOL SYSTEM:**\n")
        self.result_text.insert(tk.END, "* = Reroll same table and combine\n")
        self.result_text.insert(tk.END, "# = Roll EE table\n") 
        self.result_text.insert(tk.END, "% = Roll AE table\n")
        self.result_text.insert(tk.END, "@ = Roll QP→QE tables\n")
        self.result_text.insert(tk.END, "& = Roll RE table\n")
        self.result_text.insert(tk.END, "^ = Select item, however, No duplicates if selected again reroll\n")
        self.result_text.insert(tk.END, "$ = Weapon enhancement\n")
        self.result_text.insert(tk.END, "**item** = Unique artifacts\n")
        self.result_text.insert(tk.END, "⭐ MANUAL EE = Apply EE enhancement to ANY item\n\n")
        
        # TEST SCENARIO #1: Test Manual EE Enhancement
        self.result_text.insert(tk.END, "🎯 **TEST SCENARIO #1 - MANUAL EE ENHANCEMENT**\n")
        self.result_text.insert(tk.END, "Apply manual EE enhancement to a simple item\n\n")
        
        try:
            # Find a simple item without symbols
            simple_items = []
            for table_id, table_data in self.item_tables.items():
                if table_id not in ['EE', 'QE', 'QP', 'AE', 'RE', '1']:  # Skip enhancement and main tables
                    for item in table_data['items']:
                        if not self.has_enhancement_symbols(item['name']) and not self.is_unique_artifact(item['name']):
                            simple_items.append((table_id, item))
            
            if simple_items:
                chosen_table, chosen_item = random.choice(simple_items)
                base_name = chosen_item['name']
                self.result_text.insert(tk.END, f"🎲 TEST ITEM: '{base_name}' from Table {chosen_table}\n")
                
                # Apply manual EE enhancement
                enhanced_item, processing_log, applied_enhancements = self.apply_manual_ee_enhancement(base_name)
                
                self.result_text.insert(tk.END, f"✅ ENHANCED RESULT: {enhanced_item}\n")
                self.result_text.insert(tk.END, f"📋 PROCESSING LOG:\n")
                for i, log_entry in enumerate(processing_log, 1):
                    self.result_text.insert(tk.END, f"   {i}. {log_entry}\n")
                self.result_text.insert(tk.END, f"🔧 Applied Enhancements: {applied_enhancements}\n")
            else:
                self.result_text.insert(tk.END, "❌ NO simple items found for testing\n")
                
        except Exception as e:
            self.result_text.insert(tk.END, f"❌ ERROR: {str(e)}\n")
        
        self.result_text.insert(tk.END, "\n" + "="*60 + "\n\n")
        
        # TEST SCENARIO #2: Find real "Enchanted Enhancements*#" items
        self.result_text.insert(tk.END, "🎯 **TEST SCENARIO #2**\n")
        self.result_text.insert(tk.END, "Find random table containing 'Enchanted Enhancements*#' and test it\n\n")
        
        try:
            # Search all tables for items with "Enchanted Enhancements*#"
            ee_star_hash_items = []
            for table_id, table_data in self.item_tables.items():
                for item in table_data['items']:
                    if 'enchanted enhancements' in item['name'].lower() and '*#' in item['name']:
                        ee_star_hash_items.append((table_id, item))
            
            if ee_star_hash_items:
                # Pick a random one
                chosen_table, chosen_item = random.choice(ee_star_hash_items)
                self.result_text.insert(tk.END, f"🎲 FOUND: '{chosen_item['name']}' in Table {chosen_table}\n")
                self.result_text.insert(tk.END, f"📋 Roll range: {chosen_item['roll_from']}-{chosen_item['roll_to']}\n")
                
                # Process it
                result, log, enhancements = self.process_enhanced_item(chosen_item['name'], chosen_table)
                
                self.result_text.insert(tk.END, f"✅ FINAL RESULT: {result}\n")
                self.result_text.insert(tk.END, f"📋 PROCESSING LOG:\n")
                for i, log_entry in enumerate(log, 1):
                    self.result_text.insert(tk.END, f"   {i}. {log_entry}\n")
                self.result_text.insert(tk.END, f"🔧 Applied Enhancements: {enhancements}\n")
            else:
                self.result_text.insert(tk.END, "❌ NO 'Enchanted Enhancements*#' items found in any table\n")
                
        except Exception as e:
            self.result_text.insert(tk.END, f"❌ ERROR: {str(e)}\n")
        
        self.result_text.insert(tk.END, "\n" + "="*60 + "\n\n")
        
        # Enhancement table status
        self.result_text.insert(tk.END, "📊 **ENHANCEMENT TABLE STATUS:**\n")
        enhancement_tables = ['EE', 'QE', 'QP', 'AE', 'RE']
        loaded_count = 0
        for table_id in enhancement_tables:
            if table_id in self.item_tables:
                count = len(self.item_tables[table_id]['items'])
                self.result_text.insert(tk.END, f"   ✅ {table_id}: {count} items loaded\n")
                loaded_count += 1
            else:
                self.result_text.insert(tk.END, f"   ❌ {table_id}: NOT LOADED\n")
        
        self.result_text.insert(tk.END, f"\n🎯 **STATUS:** {loaded_count}/{len(enhancement_tables)} enhancement tables operational\n")
        
        if loaded_count >= 1:  # At least EE table for manual enhancement
            self.result_text.insert(tk.END, f"🎉 **MANUAL EE ENHANCEMENT READY!**\n")
        else:
            self.result_text.insert(tk.END, f"⚠️ **EE table missing - manual enhancement unavailable**\n")
        
        self.result_text.insert(tk.END, f"\n🧪 **Test scenarios complete! Manual EE enhancement system operational.**\n")
        self.result_text.see(tk.END)
    
    def run(self):
        """Start the application"""
        self.root.mainloop()

if __name__ == "__main__":
    print("🎲 Starting Enhanced Arcane Treasury Generator...")
    app = MagicItemGenerator()
    app.run()